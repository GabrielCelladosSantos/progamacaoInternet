let numero1 = document.querySelector("#numero1");
let botaoSomar = document.querySelector("#botaoSomar");
let resultadoa = document.querySelector("#")