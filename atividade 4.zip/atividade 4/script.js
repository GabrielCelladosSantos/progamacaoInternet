let numero1 = document.querySelector ("#numero1");
let h3resultado = document.querySelector ("#h3resultado");
let botaoSomar = document.querySelector ("#BotaoSomar");

function trocarNumero () {

    let num1 = Number(numero1.value);


h3resultado.textContent = (num1 * 1) / 100 + num1;
}

botaoSomar.onclick = function() {
    trocarNumero ();

}