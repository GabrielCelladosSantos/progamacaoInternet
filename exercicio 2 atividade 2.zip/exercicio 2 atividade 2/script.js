let inputNumber1 = document.querySelector("#inputNumber1");
let botaoSomar = document.querySelector("#botaoSomar");
let resultadoa = document.querySelector("#resultadoa");
let resultadob = document.querySelector("#resultadob");

function calculo(){
    let num1 = Number(inputNumber1.value);

    resultadoa.textContent = num1 * 2;
    resultadob.textContent = num1 * 50 + "00 g" ;
}

botaoSomar.onclick = function (){
    calculo();
}