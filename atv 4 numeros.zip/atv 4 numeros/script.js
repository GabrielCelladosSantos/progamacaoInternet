let inputNum1= document.querySelector("#inputNum1");
let inputNum2= document.querySelector("#inputNum2");
let inputNum3= document.querySelector("#inputNum3");
let inputNum4= document.querySelector("#inputNum4");
let Btmenor= document.querySelector("#Btmenor");
let h3resultado= document.querySelector("#h3resultado");

function menor(){
    let num1 = Number(inputNum1.value);
    let num2 = Number(inputNum2.value);
    let num3 = Number(inputNum3.value);
    let num4 = Number(inputNum4.value);
    if(num1== num2== num3== num4){
        h3resultado.textContent = 'coloque numeros validos'
        return;
    }if(num1<num2 && num1<num3 && num1<num4){
        h3resultado.textContent = 'menor numero'+num1;
    }if(num2<num1 && num2<num3 && num2<num4){
        h3resultado.textContent= 'menor numero'+num2;
    }if(num3<num1 && num3<num2 && num3<num4){
        h3resultado.textContent= 'menor numero'+num3;
    }if(num4<num1 && num4<num2 && num4<num3)
        h3resultado.textContent = 'menor numero'+num4;
    }


    Btmenor.onclick = function(){
        menor ();
    }

