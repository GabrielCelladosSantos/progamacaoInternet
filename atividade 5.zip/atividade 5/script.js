let numero1 = document.querySelector ("#numero1");
let numero2 = document.querySelector ("#numero2");
let numero3 = document.querySelector ("#numero3");
let botaoSomar = document.querySelector ("#botaoSomar");
let h2aritmetica = document.querySelector ("#h2aritmetica");
let h2ponderada =  document.querySelector ("#h2ponderada");
let h2somadasmedias = document.querySelector ("#h2somadasmedias");
let h2Mediadasmedias = document.querySelector ("#h2Mediadasmedias");

function calcularMedias() {
    let num1 = Number(numero1.value);
    let num2 = Number(numero2.value);
    let num3 = Number(numero3.value);
    h2aritmetica.textContent = (num1 + num2 + num3)/3;
    h2ponderada.textContent = (num1 * 3 + num2* 2 + num3*5)/10;
    h2somadasmedias.textContent = (h2aritmetica + h2ponderada );
}
botaoSomar.onclick = function (){
    calcularMedias();
}