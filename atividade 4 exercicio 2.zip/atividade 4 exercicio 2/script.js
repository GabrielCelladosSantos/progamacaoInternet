let pizza1= document.querySelector("#pizza1");
let pizza2= document.querySelector("#pizza2");
let pizza3= document.querySelector("#pizza3");
let pizza4= document.querySelector("#pizza4");
let refrigerante= document.querySelector("#refrigerante");
let btsomar= document.querySelector("#btsomar");
let resultado= document.querySelector("#resultado");

function calculo (pizza1, pizza2, pizza3, pizza4, refrigerante){
    resultado.innerHTML = "sabores da pizza <br>"
    +pizza1.value+ "<br>"
    +pizza2.value+ "<br>"
    +pizza3.value+ "<br>"
    +pizza4.value+ "<br>"
    +refrigerante.value+ "<br>"
    +"ValorTotal: R$55,00";
}
  btsomar.onclick = function (){
    calculo(pizza1, pizza2, pizza3, pizza4, refrigerante);
  }