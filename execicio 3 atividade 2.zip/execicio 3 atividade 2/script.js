let numero1 = document.querySelector("#numero1");
let numero2 = document.querySelector("#numero2");
let botaoSomar = document.querySelector("#botaoSomar");
let resultadoa = document.querySelector("#resultadoa");
let resultadob = document.querySelector("#resultadob");
let resultadoc = document.querySelector("#resultadoc");
let resultadod = document.querySelector("#resultadod");

function calculos () {
    let num1 = Number(numero1.value);
    let num2 = Number(numero2.value);

    resultadoa.textContent = (num1 + num2);
    resultadob.textContent = (num1 - num2);
    resultadoc.textContent = (num1 * num2);
    resultadod.textContent = (num1 / num2);
}

botaoSomar.onclick = function () {
    calculos ();

}