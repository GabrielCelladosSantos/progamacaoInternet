let inputNum1 = document.querySelector("#inputNum1");
let inputNum2 = document.querySelector("#inputNum2");
let BtMaior = document.querySelector("#BtMaior");
let h2Resultado = document.querySelector("#h2Resultado");

    function Maior() {
let num1 = Number(inputNum1.value);
let num2 = Number(inputNum2.value);
if(num1== num2){
    h2Resultado.textContent = 'coloque numeros validos'
    return;
    
} if(num1>num2){
    h2Resultado.textContent = 'maior numero '+num1;
}else{
        h2Resultado.textContent = ' maior numero'+num2;
    }
    }

BtMaior.onclick = function(){
    Maior ();
}v